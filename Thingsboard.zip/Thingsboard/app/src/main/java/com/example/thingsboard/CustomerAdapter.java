package com.example.thingsboard;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

class CustomerAdapter extends BaseAdapter {
    Context context;
    ArrayList<Customer> arrayList;

    public CustomerAdapter(Context context, ArrayList<Customer> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }
    private class ViewHolder{
        TextView txtName,txtAddress,txtPhone,txtEmail,txtNumber;
    }

    @Override
    public int getCount() {
        return arrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return arrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView==null){
            LayoutInflater inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView= inflater.inflate(R.layout.listview_customer,null);
            holder =new ViewHolder();
            holder.txtName=convertView.findViewById(R.id.txtCustomerName);
            holder.txtAddress=convertView.findViewById(R.id.txtAddress);
            holder.txtPhone=convertView.findViewById(R.id.txtPhone);
            holder.txtEmail=convertView.findViewById(R.id.txtEmail);
            holder.txtNumber=convertView.findViewById(R.id.txtNumberDevice);
            convertView.setTag(holder);
        }else{
            holder=(ViewHolder) convertView.getTag();
        }

        Customer _customer =arrayList.get(position);

        holder.txtAddress.setText(_customer.getAddress());
        holder.txtEmail.setText(_customer.getEmail());
        holder.txtName.setText(_customer.getName());
        holder.txtPhone.setText(_customer.getPhone());
        holder.txtNumber.setText(_customer.getNumber());
        return convertView;
    }
}
