package com.example.thingsboard;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

public class MainCustomer extends AppCompatActivity {
    ListView listViewCustomer;
    TextView txtNhietdo;
    TextView txtDoam;
    TextView txtDeviceName;
    TextView txtDay;
    WeatherAdapter weather_adapter;
    ArrayList<Weather> weatherArrayList;
    Map<String, String> result = new HashMap<>();
    ArrayList<String> stringArrayList = new ArrayList<>();
    public static String token = MainActivity.token;
    public static String refreshToken = MainActivity.refreshToken;
    public static String deviceId;
    public static String deviceName;
    public static String temp;
    public static String hum;
    public static String Day;
//    Map<String, String> result = new HashMap<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("List Device");
        setContentView(R.layout.activity_customer);
        init();
        GetDevice();
        listViewCustomer.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                deviceId = stringArrayList.get(position);
                deviceName = weatherArrayList.get(position).getDeviceName();
                String temp = weatherArrayList.get(position).getNhietdo();
                String hum = weatherArrayList.get(position).getDoam();
                Intent mainSelectIntent = new Intent(MainCustomer.this, MainSelect.class);
                mainSelectIntent.putExtra("deviceId", deviceId);
                mainSelectIntent.putExtra("token", token);
                mainSelectIntent.putExtra("deviceName", deviceName);
                startActivity(mainSelectIntent);

            }
        });
    }

    private void init() {
        listViewCustomer = (ListView) findViewById(R.id.listviewCustomer);
        txtNhietdo = (TextView) findViewById(R.id.txtNhietdo);
        txtDoam = (TextView) findViewById(R.id.txtDoam);
        txtDay = (TextView) findViewById(R.id.txtDay);
        txtDeviceName = (TextView) findViewById(R.id.txtDeviceName);
        weatherArrayList = new ArrayList<Weather>();
        weather_adapter = new WeatherAdapter(MainCustomer.this, weatherArrayList);
        listViewCustomer.setAdapter(weather_adapter);

    }

    private void GetWeather(final String deviceId) {
        Intent intent = getIntent();
        final String token = intent.getStringExtra("token");
        String refreshToken = intent.getStringExtra("refreshToken");
        String customerId = intent.getStringExtra("customerId");
        String url = "http://14.162.38.93:9000/api/plugins/telemetry/DEVICE/" + deviceId + "/values/timeseries";
        RequestQueue requestQueue = Volley.newRequestQueue(MainCustomer.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArrayTemp = jsonObject.getJSONArray("temperature");
                            JSONObject jsonObjectTemp = jsonArrayTemp.getJSONObject(0);
                            String temp = jsonObjectTemp.getString("value");
//                            result.put("nhietdo", temp);

//                            JSONArray jsonArrayID = jsonObject.getJSONArray("ID");
//                            JSONObject jsonObjectID = jsonArrayID.getJSONObject(0);
//                            String id = jsonObjectID.getString("value");

                            String day = jsonObjectTemp.getString("ts");
                            String convert = day.substring(0, 10);
                            long l = Long.valueOf(convert);
                            Date date = new Date(l * 1000L);
                            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEEE yyyy-MM-dd HH:mm:ss");
                            String Day = simpleDateFormat.format(date);
//                            result.put("Day", Day);


                            JSONArray jsonArrayHum = jsonObject.getJSONArray("humidity");
                            JSONObject jsonObjectHum = jsonArrayHum.getJSONObject(0);
                            String hum = jsonObjectHum.getString("value");
//                            result.put("doam", hum);
                            weatherArrayList.add(new Weather(Day, temp, hum, deviceId));
                            weather_adapter.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        VolleyLog.d("Error", "Error: " + error.getMessage());
                        Toast.makeText(MainCustomer.this, "" + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Accept", "application/json");
                headerMap.put("X-Authorization", "Bearer " + token);
                return headerMap;
            }
        };
        requestQueue.add(stringRequest);
    }

    private void GetDevice() {
        Intent intent = getIntent();
//        token = intent.getStringExtra("token");
//        String refreshToken = intent.getStringExtra("refreshToken");
        token = MainActivity.token;
        refreshToken = MainActivity.refreshToken;
        String customerId = intent.getStringExtra("customerId");
        String url = "http://14.162.38.93:9000/api/customer/" + customerId + "/devices?limit=1000";
        RequestQueue requestQueue = Volley.newRequestQueue(MainCustomer.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObjectData = jsonArray.getJSONObject(i);
                                JSONObject jsonObjectDeviceId = jsonObjectData.getJSONObject("id");
                                final String deviceId = jsonObjectDeviceId.getString("id");
                                Log.d("deviceId", deviceId);
                                stringArrayList.add(deviceId);
                                final String name = jsonObjectData.getString("name");
                                String url_device = "http://14.162.38.93:9000/api/plugins/telemetry/DEVICE/" + deviceId + "/values/timeseries";
                                RequestQueue requestQueue2 = Volley.newRequestQueue(MainCustomer.this);
                                StringRequest stringRequest2 = new StringRequest(Request.Method.GET, url_device,
                                        new Response.Listener<String>() {
                                            @Override
                                            public void onResponse(String response) {
                                                try {
                                                    JSONObject jsonObject2 = new JSONObject(response);
                                                    JSONArray jsonArraytemp = jsonObject2.getJSONArray("temperature");
                                                    JSONArray jsonArrayhum = jsonObject2.getJSONArray("humidity");
                                                    JSONObject jsonTemp = jsonArraytemp.getJSONObject(0);
                                                    temp = jsonTemp.getString("value");
                                                    JSONObject jsonHum = jsonArrayhum.getJSONObject(0);
                                                    hum = jsonHum.getString("value");
                                                    String day = jsonHum.getString("ts");
                                                    String convert = day.substring(0, 10);
                                                    long l = Long.valueOf(convert);
                                                    Date date = new Date(l * 1000L);
                                                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                                                    simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+7"));
                                                    Day = simpleDateFormat.format(date);
                                                    weatherArrayList.add(new Weather(Day, temp, hum, deviceId, name));
                                                    weather_adapter.notifyDataSetChanged();

                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                            }
                                        },
                                        new Response.ErrorListener() {
                                            @Override
                                            public void onErrorResponse(VolleyError error) {

                                            }
                                        }) {
                                    @Override
                                    public Map<String, String> getHeaders() throws AuthFailureError {
                                        Map<String, String> headerMap = new HashMap<String, String>();
                                        headerMap.put("Accept", "application/json");
                                        headerMap.put("X-Authorization", "Bearer " + token);
                                        return headerMap;
                                    }
                                };
                                requestQueue2.add(stringRequest2);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        VolleyLog.d("Error", "Error: " + error.getMessage());
                        Toast.makeText(MainCustomer.this, "" + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Accept", "application/json");
                headerMap.put("X-Authorization", "Bearer " + token);
                return headerMap;
            }
        };
        requestQueue.add(stringRequest);
    }
}
