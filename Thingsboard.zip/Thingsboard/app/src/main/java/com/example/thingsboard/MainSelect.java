package com.example.thingsboard;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainSelect extends AppCompatActivity {
    Button btnChart;
    Button btnMap;
    Button btnYoutube;
    public static String deviceId = "";
    public static String deviceName = "";
    public static String token = MainActivity.token;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Select");
        setContentView(R.layout.activity_main_select);
        final Intent intent = getIntent();
        deviceId = intent.getStringExtra("deviceId");
        deviceName = intent.getStringExtra("deviceName");
        init();
        btnChart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentChart = new Intent(MainSelect.this, Chart.class);
                intentChart.putExtra("deviceId", deviceId);
                intentChart.putExtra("deviceName", deviceName);
                startActivity(intentChart);
            }
        });
        btnYoutube.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentYoutube = new Intent(MainSelect.this, MainYoutube.class);
                intentYoutube.putExtra("deviceId", deviceId);
                intentYoutube.putExtra("deviceName", deviceName);
                startActivity(intentYoutube);
            }
        });
        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intentMap = new Intent(MainSelect.this, MainGoogleMap.class);
                intentMap.putExtra("deviceId", deviceId);
                intentMap.putExtra("deviceName", deviceName);
                startActivity(intentMap);
            }
        });

    }

    private void init() {
        btnChart = (Button) findViewById(R.id.buttonChart);
        btnMap = (Button) findViewById(R.id.buttonMap);
        btnYoutube = (Button) findViewById(R.id.buttonYoutube);
    }
}
