package com.example.thingsboard;

public class Weather {
    public String Day;
    public String Nhietdo;
    public String Doam;
    public String DeviceId;
    public String DeviceName;

    public Weather(String DeviceName) {
        this.DeviceName = DeviceName;
    }

    public Weather(String day, String nhietdo, String doam, String DeviceName) {
        Day = day;
        Nhietdo = nhietdo;
        Doam = doam;
        this.DeviceName = DeviceName;
    }

    public Weather(String day, String nhietdo, String doam, String deviceId, String DeviceName) {
        Day = day;
        Nhietdo = nhietdo;
        Doam = doam;
        DeviceId = deviceId;
        this.DeviceName = DeviceName;
    }

    public String getDay() {
        return Day;
    }

    public void setDay(String day) {
        Day = day;
    }

    public String getNhietdo() {
        return Nhietdo;
    }

    public void setNhietdo(String nhietdo) {
        Nhietdo = nhietdo;
    }

    public String getDoam() {
        return Doam;
    }

    public void setDoam(String doam) {
        Doam = doam;
    }

    public String getDeviceId() {
        return DeviceId;
    }

    public void setDeviceId(String deviceId) {
        DeviceId = deviceId;
    }

    public String getDeviceName() {
        return DeviceName;
    }

    public void setDeviceName(String deviceName) {
        this.DeviceName = deviceName;
    }
}
