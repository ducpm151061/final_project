package com.example.thingsboard;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainTenant extends AppCompatActivity {
    ListView listViewTenant;
    public static String token = MainActivity.token;
    public static String refreshToken;
    TextView txtName;
    TextView txtNumber;
    TextView txtAddress;
    TextView txtPhone;
    TextView txtEmail;
    ArrayList<String> stringArrayList = new ArrayList<>();
    CustomerAdapter customer_adapter;
    ArrayList<Customer> arrayListCustomers;
    Map<String, String> result = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("List Customer");
        setContentView(R.layout.activity_tenant);
        init();
        GetCustomer();
        listViewTenant.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String customerId=arrayListCustomers.get(position).getId();
                Intent mainSelectIntent = new Intent(MainTenant.this, MainCustomer.class);
                mainSelectIntent.putExtra("customerId",customerId);
                startActivity(mainSelectIntent);
            }
        });

    }

    private void init() {
        txtName = (TextView) findViewById(R.id.txtCustomerName);
        txtNumber = (TextView) findViewById(R.id.txtNumberDevice);
        txtAddress = (TextView) findViewById(R.id.txtAddress);
        txtPhone = (TextView) findViewById(R.id.txtPhone);
        txtEmail = (TextView) findViewById(R.id.txtEmail);
        listViewTenant = (ListView) findViewById(R.id.listviewTenant);
        arrayListCustomers = new ArrayList<Customer>();
        customer_adapter = new CustomerAdapter(MainTenant.this, arrayListCustomers);
        listViewTenant.setAdapter(customer_adapter);


    }

    //    private void GetWeather1() {
//        Intent intent=getIntent();
//        final String token=intent.getStringExtra("token");
//        String refreshToken=intent.getStringExtra("refreshToken");
//        String url = "http://40.117.86.51:8080/api/tenant/devices?limit=1000";
//        RequestQueue requestQueue = Volley.newRequestQueue(Tenant.this);
//        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
//                new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        try {
//                            JSONObject jsonObject=new JSONObject(response);
//                            JSONArray jsonArrayTemp=jsonObject.getJSONArray("temperature");
//                            JSONObject jsonObjectTemp=jsonArrayTemp.getJSONObject(0);
//                            String temp=jsonObjectTemp.getString("value");
//                            txtTemp1.setText("Nhiet do: "+temp);
//
//                            JSONArray jsonArrayID=jsonObject.getJSONArray("ID");
//                            JSONObject jsonObjectID=jsonArrayID.getJSONObject(0);
//                            String id=jsonObjectID.getString("value");
//                            txtDevice1.setText("ID: "+id);
//
//                            String day=jsonObjectTemp.getString("ts");
//                            String convert=day.substring(0,10);
//                            long l = Long.valueOf(convert);
//                            Date date = new Date(l * 1000L);
//                            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEEE yyyy-MM-dd HH:mm:ss");
//                            String Day = simpleDateFormat.format(date);
//                            txtDay1.setText("Ngay: "+Day);
//
//                            JSONArray jsonArrayHum=jsonObject.getJSONArray("humidity");
//                            JSONObject jsonObjectHum=jsonArrayHum.getJSONObject(0);
//                            String hum=jsonObjectHum.getString("value");
//                            txtHum1.setText("Do am: "+hum);
//
//
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        }
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        VolleyLog.d("Error", "Error: " + error.getMessage());
//                        Toast.makeText(Tenant.this, "" + error.getMessage(), Toast.LENGTH_SHORT).show();
//                    }
//                }) {
//            @Override
//            public Map<String, String> getHeaders() throws AuthFailureError {
//                Map<String, String> headerMap = new HashMap<String, String>();
//                headerMap.put("Accept", "application/json");
//                headerMap.put("X-Authorization", "Bearer " + token);
//                return headerMap;
//            }
//        };
//        requestQueue.add(stringRequest);
//    }
    private void GetCustomer() {
        Intent intent = getIntent();
//        token=MainActivity.token;
        refreshToken = MainActivity.refreshToken;

        String url = "http://14.162.38.93:9000/api/customers?limit=10";
        RequestQueue requestQueue = Volley.newRequestQueue(MainTenant.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObjectData = jsonArray.getJSONObject(i);
                                Log.d("result", result.toString());
                                final String name = jsonObjectData.getString("name");
                                final String address = jsonObjectData.getString("address");
                                final String phone = jsonObjectData.getString("phone");
                                final String email = jsonObjectData.getString("email");
                                JSONObject jsonObjectId = jsonObjectData.getJSONObject("id");
                                final String customerId = jsonObjectId.getString("id");
                                String url = "http://14.162.38.93:9000/api/customer/" + customerId + "/devices?limit=10";
                                RequestQueue requestQueue2 = Volley.newRequestQueue(MainTenant.this);
                                StringRequest stringRequest2 = new StringRequest(Request.Method.GET, url,
                                        new Response.Listener<String>() {
                                            @Override
                                            public void onResponse(String response) {
                                                try {
                                                    JSONObject jsonObject2 = new JSONObject(response);
                                                    JSONArray jsonArray2 = jsonObject2.getJSONArray("data");
                                                    int number = jsonArray2.length();
                                                    arrayListCustomers.add(new Customer(name, phone, email, address, new String("Device: " + number),customerId));
                                                    customer_adapter.notifyDataSetChanged();
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                            }
                                        },
                                        new Response.ErrorListener() {
                                            @Override
                                            public void onErrorResponse(VolleyError error) {
                                                VolleyLog.d("Error", "Error: " + error.getMessage());
                                                Toast.makeText(MainTenant.this, "" + error.getMessage(), Toast.LENGTH_SHORT).show();
                                            }
                                        }) {
                                    @Override
                                    public Map<String, String> getHeaders() throws AuthFailureError {
                                        Map<String, String> headerMap = new HashMap<String, String>();
                                        headerMap.put("Accept", "application/json");
                                        headerMap.put("X-Authorization", "Bearer " + token);
                                        return headerMap;
                                    }
                                };
                                requestQueue2.add(stringRequest2);

//                                arrayListCustomers.add(new Customer(name,phone,email,address,"2"));
                            }
                            customer_adapter.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        VolleyLog.d("Error", "Error: " + error.getMessage());
                        Toast.makeText(MainTenant.this, "" + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Accept", "application/json");
                headerMap.put("X-Authorization", "Bearer " + token);
                return headerMap;
            }
        };
        requestQueue.add(stringRequest);
    }
}
