package com.example.thingsboard;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
//import com.auth0.jwt.JWT;
import com.auth0.android.jwt.*;

import org.apache.commons.codec.binary.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class MainActivity extends AppCompatActivity {
    Button btnLogin;
    EditText edtUsername;
    EditText edtPassword;
    public static String token = "";
    public static String refreshToken = "";

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        setContentView(R.layout.activity_main);
        init();
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getoken();
            }
        });

    }

    private void init() {
        btnLogin = (Button) findViewById(R.id.buttonLogin);
        edtUsername = (EditText) findViewById(R.id.editTextUsername);
        edtPassword = (EditText) findViewById(R.id.editTextPassword);

    }

    private void getUser() throws JSONException {
        String tk = "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJjdXN0b21lckFAdGhpbmdzYm9hcmQub3JnIiwic2NvcGVzIjpbIkNVU1RPTUVSX1VTRVIiXSwidXNlcklkIjoiYjVhOGI4MDAtN2NjYi0xMWVhLTlkZTAtMDlmMjRkOTdjZjdhIiwiZW5hYmxlZCI6dHJ1ZSwiaXNQdWJsaWMiOmZhbHNlLCJ0ZW5hbnRJZCI6ImI1M2U1ZDcwLTdjY2ItMTFlYS05ZGUwLTA5ZjI0ZDk3Y2Y3YSIsImN1c3RvbWVySWQiOiJiNTg1MmE3MC03Y2NiLTExZWEtOWRlMC0wOWYyNGQ5N2NmN2EiLCJpc3MiOiJ0aGluZ3Nib2FyZC5pbyIsImlhdCI6MTU4OTkwMjk5MiwiZXhwIjoxNTg5OTExOTkyfQ.Kd8jDG2k3TyPNrLKqMJhv2nsNDaWImoii7E2WJgnA8Tp-0sVJ5eep539oPjaCgEF-Bz4fOtm8KtD6mVIzsENtg";
        JWT jwt = new JWT(tk);
        String subject = jwt.getSubject();
        JSONObject jsonObject = new JSONObject(tk);
        Log.d("json", jsonObject.toString());
        Map<String, Claim> claims = jwt.getClaims();    //Key is the Claim name
        Claim claim = claims.get("scopes");
        Log.d("jwt", subject);

    }

    private Map<String, String> decodeBase64(String data) throws JSONException {
        Map<String, String> result = new HashMap<>();
        String[] split_string = data.split("\\.");
        Log.d("body",split_string.toString());
        String base64EncodedHeader = split_string[0];
        String base64EncodedBody = split_string[1];
//        String base64EncodedSignature = split_string[2];
        byte[] bytes = new org.apache.commons.codec.binary.Base64().decode(StringUtils.getBytesUtf8(data));
//        return new String(bytes);
        byte[] header = new org.apache.commons.codec.binary.Base64().decode(StringUtils.getBytesUtf8(base64EncodedHeader));
//        byte[] body = new org.apache.commons.codec.binary.Base64().decode(StringUtils.getBytesUtf8(base64EncodedBody));
        byte[] body= Base64.decode(base64EncodedBody,0);
        JSONObject jsonObject = new JSONObject(new String(body));
        String sub = jsonObject.getString("sub");
        String customerId = jsonObject.getString("customerId");
        JSONArray jsonArray = jsonObject.getJSONArray("scopes");
        String scopes = jsonArray.getString(0);
        String userId = jsonObject.getString("userId");
        String exp = jsonObject.getString("exp");
        result.put("sub", sub);
        result.put("customerId", customerId);
        result.put("scopes", scopes);
        result.put("exp", exp);
        result.put("userId",userId);
        return result;
    }

    private void GetToken() {
//        final String user = edtUsername.getText().toString();
//        final String pass = edtPassword.getText().toString();
        String url = "http://40.117.86.51:8080/api/auth/login";
        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("token", response.toString());
                        Toast.makeText(MainActivity.this, response.toString(), Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        VolleyLog.d("Error", "Error: " + error.getMessage());
                        Toast.makeText(MainActivity.this, "" + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json");
                params.put("Accept", "application/json");
                return params;
            }

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("username", "tenant@thingsboard.org");
                params.put("password", "tenant");
                return params;
            }
        };
        requestQueue.add(stringRequest);
    }

    private void getoken() {
        String url = "http://14.162.38.93:9000/api/auth/login";
        String user = edtUsername.getText().toString().trim();
        String pass = edtPassword.getText().toString().trim();
        Map<String, String> params = new HashMap();
        params.put("username", user);
        params.put("password", pass);

        JSONObject parameters = new JSONObject(params);

        JsonObjectRequest jsonRequest = new JsonObjectRequest(Request.Method.POST, url, parameters, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    token = response.getString("token");
                    Log.d("token", token);
                    refreshToken = response.getString("refreshToken");
                    Log.d("refresh", refreshToken);
                    Intent tenantIntent = new Intent(MainActivity.this, MainTenant.class);
                    Intent customerIntent =new Intent(MainActivity.this, MainCustomer.class);
                    Map<String,String> result= decodeBase64(token);
                    tenantIntent.putExtra("userId",result.get("userId"));
                    tenantIntent.putExtra("exp",result.get("exp"));
                    tenantIntent.putExtra("customerId",result.get("customerId"));
                    tenantIntent.putExtra("scopes",result.get("scopes"));

//                    customerIntent.putExtra("token", getToken());
//                    customerIntent.putExtra("refreshToken", getRefreshToken());
                    customerIntent.putExtra("userId",result.get("userId"));
                    customerIntent.putExtra("exp",result.get("exp"));
                    customerIntent.putExtra("customerId",result.get("customerId"));
                    customerIntent.putExtra("scopes",result.get("scopes"));
                    if(result.get("scopes").equals("CUSTOMER_USER"))
                        startActivity(customerIntent);
                    if(result.get("scopes").equals("TENANT_ADMIN"))
                        startActivity(tenantIntent);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                Toast.makeText(MainActivity.this,"Sai tài khoản hoặc mật khẩu",Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json");
                params.put("Accept", "application/json");
                return params;
            }
        };

        Volley.newRequestQueue(this).add(jsonRequest);
    }

    private void getNewtoken() {
        String url = "http://40.117.86.51:8080/api/auth/token";
        Map<String, String> params = new HashMap();
        String rf = "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ0ZW5hbnRAdGhpbmdzYm9hcmQub3JnIiwic2NvcGVzIjpbIlJFRlJFU0hfVE9LRU4iXSwidXNlcklkIjoiYjU2ZjU4ODAtN2NjYi0xMWVhLTlkZTAtMDlmMjRkOTdjZjdhIiwiaXNQdWJsaWMiOmZhbHNlLCJpc3MiOiJ0aGluZ3Nib2FyZC5pbyIsImp0aSI6ImVkNWM0YTllLWJlNzUtNDkzMC1hZGQzLThiNjU2MTRkZDRhZSIsImlhdCI6MTU4ODkxODg4OSwiZXhwIjoxNTg5NTIzNjg5fQ.X2Q01POe8HTvvZBRVHaFAXBXN9lF1l86QZ07nFx5CzWlmPliHe6TjiF24C15YMSDIbMPExE71XGT7YJH0zL-zw";
        final String tk = "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ0ZW5hbnRAdGhpbmdzYm9hcmQub3JnIiwic2NvcGVzIjpbIlRFTkFOVF9BRE1JTiJdLCJ1c2VySWQiOiJiNTZmNTg4MC03Y2NiLTExZWEtOWRlMC0wOWYyNGQ5N2NmN2EiLCJlbmFibGVkIjp0cnVlLCJpc1B1YmxpYyI6ZmFsc2UsInRlbmFudElkIjoiYjUzZTVkNzAtN2NjYi0xMWVhLTlkZTAtMDlmMjRkOTdjZjdhIiwiY3VzdG9tZXJJZCI6IjEzODE0MDAwLTFkZDItMTFiMi04MDgwLTgwODA4MDgwODA4MCIsImlzcyI6InRoaW5nc2JvYXJkLmlvIiwiaWF0IjoxNTg4OTE4ODg5LCJleHAiOjE1ODg5Mjc4ODl9.DC0bjKKUIiFpOvvmlAztA4ZGfC8pEP3xC92CMxRllVt6-bTEFM-RAMqjZuVFmvAEH5exr45FYDW_LFGte2Rtww";
        params.put("refreshToken", rf);
        JSONObject parameters = new JSONObject(params);

        JsonObjectRequest jsonRequest = new JsonObjectRequest(Request.Method.POST, url, parameters, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    token = response.getString("token");
                    Log.d("token2", token);
                    refreshToken = response.getString("refreshToken");
                    Log.d("refresh2", refreshToken);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                //TODO: handle failure
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json");
                params.put("X-Authorization", "Bearer " + tk);
                return params;
            }
        };

        Volley.newRequestQueue(this).add(jsonRequest);
    }

}
