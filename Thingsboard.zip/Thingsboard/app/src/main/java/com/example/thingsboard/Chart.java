package com.example.thingsboard;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.drafts.Draft;
import org.java_websocket.handshake.ServerHandshake;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;

//import com.pusher.java_websocket.client.WebSocketClient;
//import com.pusher.java_websocket.handshake.ServerHandshake;

public class Chart extends AppCompatActivity {
    private LineChart mChart;
    private TextView txtData;
    private static final float TOTAL_MEMORY = 100.0f;
    private static final float LIMIT_MAX_MEMORY = 12.0f;
    public String token = MainActivity.token;

    class DateAxisValueFormatter implements IAxisValueFormatter {
        private String[] mValues;

        SimpleDateFormat sdf = new SimpleDateFormat("dd:MM:yyyy hh:mm:ss");

        public DateAxisValueFormatter(String[] values) {
            this.mValues = values;
        }


        @Override
        public String getFormattedValue(float value, AxisBase axis) {
            // "value" represents the position of the label on the axis (x or y)
            return mValues[(int) value];
        }
    }

    public class ExampleClient extends WebSocketClient {
        public ExampleClient(URI serverUri, Draft draft) {
            super(serverUri, draft);
        }

        public ExampleClient(URI serverURI) {
            super(serverURI);
        }

        public ExampleClient(URI serverUri, Map<String, String> httpHeaders) {
            super(serverUri, httpHeaders);
        }

        @Override
        public void onOpen(ServerHandshake handshakedata) {
            Intent intent = getIntent();
            String entityId = intent.getStringExtra("deviceId");

            String text = "{\"tsSubCmds\": [{\"entityType\": \"DEVICE\",\"entityId\": \"" + entityId + "\",\"scope\": \"LATEST_TELEMETRY\",\"cmdId\": \"10\"}],\"historyCmds\": [],\"attrSubCmds\": []}";
            send(text);
//            send("{\"tsSubCmds\": [{\"entityType\": \"DEVICE\",\"entityId\": \"95ba4b80-9f6c-11ea-83d6-c9ea24e2a650\",\"scope\": \"LATEST_TELEMETRY\",\"cmdId\": \"10\"}],\"historyCmds\": [],\"attrSubCmds\": []}");
            System.out.println("opened connection");
            // if you plan to refuse connection based on ip or httpfields overload: onWebsocketHandshakeReceivedAsClient
        }

        @Override
        public void onMessage(String message) {
            System.out.println("received: " + message);
            try {
                JSONObject jsonObject = new JSONObject(message);
                Log.d("json", message);
                JSONObject jsonData = jsonObject.getJSONObject("data");
                JSONArray jsonArrayTemp = jsonData.getJSONArray("temperature");
                JSONArray jsonArrayHum = jsonData.getJSONArray("humidity");
                JSONArray jsonTemp = jsonArrayTemp.getJSONArray(0);
                String temp = jsonTemp.getString(1);
                JSONArray jsonHum = jsonArrayHum.getJSONArray(0);
                String day = jsonHum.getString(0);
                String convert = day.substring(0, 10);
                long l = Long.valueOf(convert);
                Date date = new Date(l * 1000L);
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss dd-MM-yyyy");
                simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+7"));
                String Day = simpleDateFormat.format(date);
                String[] ArrDay = new String[]{Day};
                Log.d("date", Day);
                String hum = jsonHum.getString(1);
                Log.d("temp", temp);
                Log.d("hum", hum);
                addEntry(temp, hum, ArrDay);
                txtData.setText("Temperature: " + temp + "°C Humidity: " + hum + "%" + "\n Date: " + Day);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onClose(int code, String reason, boolean remote) {
            // The codecodes are documented in class org.java_websocket.framing.CloseFrame
            System.out.println("Connection closed by " + (remote ? "remote peer" : "us") + " Code: " + code + " Reason: " + reason);
        }

        @Override
        public void onError(Exception ex) {
            ex.printStackTrace();
            // if the error is fatal then onClose will be called additionally
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Chart");
        setContentView(R.layout.activity_chart);
        mChart = (LineChart) findViewById(R.id.chart);
        txtData = (TextView) findViewById(R.id.textViewData);

        setupChart();
        setupAxes();
        setupData();
        setLegend();
        try {
            String url = "ws://14.162.38.93:9000/api/ws/plugins/telemetry?token=" + token;
            Log.d("url", url);
            ExampleClient exampleClient = new ExampleClient(new URI(url));
            exampleClient.connect();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }

    private void setupChart() {
        // disable description text
        mChart.getDescription().setEnabled(false);
        // enable touch gestures
        mChart.setTouchEnabled(true);
        // if disabled, scaling can be done on x- and y-axis separately
        mChart.setPinchZoom(true);
        // enable scaling
        mChart.setScaleEnabled(true);
        mChart.setDrawGridBackground(false);
        // set an alternative background9 color
        mChart.setBackgroundColor(Color.DKGRAY);
    }

    private void setupAxes() {
        XAxis xl = mChart.getXAxis();
        xl.setTextColor(Color.WHITE);
        xl.setDrawGridLines(false);
        xl.setAvoidFirstLastClipping(true);
        xl.setEnabled(true);

        YAxis leftAxis = mChart.getAxisLeft();
        leftAxis.setTextColor(Color.WHITE);
        leftAxis.setAxisMaximum(TOTAL_MEMORY);
        leftAxis.setAxisMinimum(0f);
        leftAxis.setDrawGridLines(true);

        YAxis rightAxis = mChart.getAxisRight();
        rightAxis.setEnabled(false);

        // Add a limit line
//        LimitLine ll = new LimitLine(LIMIT_MAX_MEMORY, "Upper Limit");
//        ll.setLineWidth(2f);
//        ll.setLabelPosition(LimitLine.LimitLabelPosition.RIGHT_TOP);
//        ll.setTextSize(10f);
//        ll.setTextColor(Color.WHITE);
//        // reset all limit lines to avoid overlapping lines
//        leftAxis.removeAllLimitLines();
//        leftAxis.addLimitLine(ll);
//        // limit lines are drawn behind data (and not on top)
//        leftAxis.setDrawLimitLinesBehindData(true);
    }

    private void setupData() {
        ArrayList<ILineDataSet> dataSets = new ArrayList<>();
        LineData data = new LineData(dataSets);
        data.setValueTextColor(Color.WHITE);

        // add empty data
        mChart.setData(data);
    }

    private void setLegend() {
        // get the legend (only possible after setting data)
        Legend l = mChart.getLegend();

        // modify the legend ...
        l.setForm(Legend.LegendForm.CIRCLE);
        l.setTextColor(Color.WHITE);
    }

    private LineDataSet createSet(String label, int color) {
        LineDataSet set = new LineDataSet(null, label);
        set.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        set.setDrawFilled(true);
        set.setAxisDependency(YAxis.AxisDependency.LEFT);
        set.setColors(color);
        set.setCircleColor(color);
        set.setLineWidth(2f);
        set.setCircleRadius(4f);
        set.setValueTextColor(color);
        set.setValueTextSize(10f);
        // To show values of each point
        set.setDrawValues(true);
        return set;
    }

    private void addEntry(String t, String h, String[] Date) {
        LineData data = mChart.getData();
        if (data != null) {
            ILineDataSet set = data.getDataSetByIndex(0);
            ILineDataSet set2 = data.getDataSetByIndex(1);

            if (set == null) {
                set = createSet("Temperature (°C)", Color.GREEN);
//                set.setValueTextColor(Color.YELLOW);
                set2 = createSet("Humidity (%)", Color.YELLOW);
//                set2.setValueTextColor(Color.GREEN);
                data.addDataSet(set);
                data.addDataSet(set2);
            }
            float x = (float) (Math.random() * 100);
            data.addEntry(new Entry(set.getEntryCount(), Float.parseFloat(t)), 0);
            data.addEntry(new Entry(set2.getEntryCount(), Float.parseFloat(h)), 1);

            if (set.getEntryCount() >= 15) {
                set.removeFirst();
                set2.removeFirst();
                for (int i = 0; i < set.getEntryCount(); i++) {
                    Entry entryToChange = set.getEntryForIndex(i);
                    Entry entryToChange2 = set2.getEntryForIndex(i);
                    float limit = entryToChange.getX() - 1;
                    entryToChange.setX(limit);
                    entryToChange2.setX(limit);
                }
            }

            mChart.getXAxis().setDrawLabels(false);
            mChart.getXAxis().setDrawAxisLine(false);
            mChart.notifyDataSetChanged();

            // limit the number of visible entries
            if (data.getEntryCount() >= 10) {
                mChart.setVisibleXRangeMaximum(10);
            } else {
                mChart.fitScreen();
            }
            // let the chart know it's data has changed
            data.notifyDataChanged();
            // move to the latest entry
            mChart.moveViewToX(data.getEntryCount());
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }


}
