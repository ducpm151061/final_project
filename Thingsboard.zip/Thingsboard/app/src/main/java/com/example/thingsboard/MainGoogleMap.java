package com.example.thingsboard;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.drafts.Draft;
import org.java_websocket.handshake.ServerHandshake;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

public class MainGoogleMap extends AppCompatActivity implements OnMapReadyCallback {
    public static String deviceId;
    public static String deviceName;
    public static String token = MainActivity.token;
    public static String hum = "";
    public static String temp = "";
    public static String Day = "";
    public static String lat = "";
    public static String lng = "";
    public static LatLng latLng = new LatLng(21.0042838, 105.8415126);
    GoogleMap map;

    public interface VolleyCallBack {
        void onSuccess();
    }

    public class ExampleClient extends WebSocketClient {
        public ExampleClient(URI serverUri, Draft draft) {
            super(serverUri, draft);
        }

        public ExampleClient(URI serverURI) {
            super(serverURI);
        }

        public ExampleClient(URI serverUri, Map<String, String> httpHeaders) {
            super(serverUri, httpHeaders);
        }

        @Override
        public void onOpen(ServerHandshake handshakedata) {
            Intent intent = getIntent();
            String entityId = intent.getStringExtra("deviceId");

            String text = "{\"tsSubCmds\": [{\"entityType\": \"DEVICE\",\"entityId\": \"" + entityId + "\",\"scope\": \"LATEST_TELEMETRY\",\"cmdId\": \"10\"}],\"historyCmds\": [],\"attrSubCmds\": []}";
            send(text);
//            send("{\"tsSubCmds\": [{\"entityType\": \"DEVICE\",\"entityId\": \"95ba4b80-9f6c-11ea-83d6-c9ea24e2a650\",\"scope\": \"LATEST_TELEMETRY\",\"cmdId\": \"10\"}],\"historyCmds\": [],\"attrSubCmds\": []}");
            System.out.println("opened connection");
            // if you plan to refuse connection based on ip or httpfields overload: onWebsocketHandshakeReceivedAsClient
        }

        @Override
        public void onMessage(String message){
            System.out.println("received: " + message);
            try {
                JSONObject jsonObject = new JSONObject(message);
                Log.d("json", message);
                JSONObject jsonData = jsonObject.getJSONObject("data");
                JSONArray jsonArrayTemp = jsonData.getJSONArray("temperature");
                JSONArray jsonArrayHum = jsonData.getJSONArray("humidity");
                JSONArray jsonArrayLat = jsonData.getJSONArray("latitude");
                JSONArray jsonArrayLng = jsonData.getJSONArray("longitude");
                JSONArray jsonLat = jsonArrayLat.getJSONArray(0);
                lat = jsonLat.getString(1);
                JSONArray jsonLng = jsonArrayLng.getJSONArray(0);
                lng = jsonLng.getString(1);
                JSONArray jsonTemp = jsonArrayTemp.getJSONArray(0);
                temp = jsonTemp.getString(1);
                JSONArray jsonHum = jsonArrayHum.getJSONArray(0);
                String day = jsonHum.getString(0);
                String convert = day.substring(0, 10);
                long l = Long.valueOf(convert);
                Date date = new Date(l * 1000L);
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+7"));
                String Day = simpleDateFormat.format(date);
                String[] ArrDay = new String[]{Day};
                Log.d("date", Day);
                String hum = jsonHum.getString(1);
                Log.d("temp", temp);
                Log.d("hum", hum);
                latLng = new LatLng(Double.parseDouble(lat), Double.parseDouble(lng));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onClose(int code, String reason, boolean remote) {
            // The codecodes are documented in class org.java_websocket.framing.CloseFrame
            System.out.println("Connection closed by " + (remote ? "remote peer" : "us") + " Code: " + code + " Reason: " + reason);
        }

        @Override
        public void onError(Exception ex) {
            ex.printStackTrace();
            // if the error is fatal then onClose will be called additionally
        }


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Map");
        setContentView(R.layout.activity_main_google_map);

        MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.myMap);

        mapFragment.getMapAsync(this);

    }

    @Override
    public void onMapReady( GoogleMap googleMap) {
        try {
            String url = "ws://14.162.38.93:9000/api/ws/plugins/telemetry?token=" + token;
            Log.d("url", url);
            ExampleClient exampleClient = new ExampleClient(new URI(url));
            exampleClient.connect();
            Log.d("latlng", latLng.toString());
            map = googleMap;
            Log.d("latitude", lat);
            Log.d("longitude", lng);
            map.addMarker(new MarkerOptions()
                    .title(deviceName)
                    .snippet("temp: " + temp + " hum: " + hum + " Day: " + Day)
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
                    .position(latLng));
            map.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 16));
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }

    }


    public void GetWeather(String deviceId, final VolleyCallBack callback) {
        String url = "http://14.162.38.93:9000/api/plugins/telemetry/DEVICE/" + deviceId + "/values/timeseries";
        RequestQueue requestQueue = Volley.newRequestQueue(MainGoogleMap.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArrayTemp = jsonObject.getJSONArray("temperature");
                            JSONObject jsonObjectTemp = jsonArrayTemp.getJSONObject(0);
                            temp = jsonObjectTemp.getString("value");

                            String day = jsonObjectTemp.getString("ts");
                            String convert = day.substring(0, 10);
                            long l = Long.valueOf(convert);
                            Date date = new Date(l * 1000L);
                            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss EEEE dd-MM-yyyy ");
                            simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+7"));
                            Day = simpleDateFormat.format(date);


                            JSONArray jsonArrayHum = jsonObject.getJSONArray("humidity");
                            JSONObject jsonObjectHum = jsonArrayHum.getJSONObject(0);
                            hum = jsonObjectHum.getString("value");

                            JSONArray jsonArrayLat = jsonObject.getJSONArray("latitude");
                            JSONObject jsonObjectLat = jsonArrayLat.getJSONObject(0);
                            lat = jsonObjectLat.getString("value");

                            JSONArray jsonArrayLng = jsonObject.getJSONArray("longitude");
                            JSONObject jsonObjectLng = jsonArrayLng.getJSONObject(0);
                            lng = jsonObjectLng.getString("value");
                            latLng = new LatLng(Double.parseDouble(lat), Double.parseDouble(lng));
                            callback.onSuccess();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        VolleyLog.d("Error", "Error: " + error.getMessage());
                        Toast.makeText(MainGoogleMap.this, "" + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Accept", "application/json");
                headerMap.put("X-Authorization", "Bearer " + token);
                return headerMap;
            }
        };
        requestQueue.add(stringRequest);
    }

    public void GetLatLng(String deviceId, final VolleyCallBack callBack) {
        String url = "http://14.162.38.93:9000/api/plugins/telemetry/DEVICE/" + deviceId + "/values/attributes";
        RequestQueue requestQueue = Volley.newRequestQueue(MainGoogleMap.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray jsonArray = new JSONArray(response);
                            JSONObject jsonObject0 = jsonArray.getJSONObject(0);
                            JSONObject jsonObject1 = jsonArray.getJSONObject(1);
                            if (jsonObject0.getString("key").equals("latitude")) {
                                lat = jsonObject0.getString("value");
                                lng = jsonObject1.getString("value");
                                latLng = new LatLng(Double.parseDouble(lat), Double.parseDouble(lng));
                            } else {
                                lat = jsonObject1.getString("value");
                                lng = jsonObject0.getString("value");
                                latLng = new LatLng(Double.parseDouble(lat), Double.parseDouble(lng));
                            }
                            callBack.onSuccess();


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        VolleyLog.d("Error", "Error: " + error.getMessage());
                        Toast.makeText(MainGoogleMap.this, "" + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Accept", "application/json");
                headerMap.put("X-Authorization", "Bearer " + token);
                return headerMap;
            }
        };
        requestQueue.add(stringRequest);
    }

    public void Update(LatLng latLng) {

    }

}